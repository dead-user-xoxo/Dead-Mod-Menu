Hi This Is Mod Menu For The Game: Gorilla Tag Made By Dead!      


Menu Version:V1 
Menu type:Beta



THIS MENU IS STILL BEING MADE THE MENU/MODS MAY BE BUGGY I WILL REMOVE THIS TEXT WHEN IT IS FINISH!



hi so the souce code for this mod menu is kept private to stop skidding! (tho might chance idk yet!)




Credits!

Name:Dead 
Reason:Menu dev And Owner

Name:Malachi
Reason:i used his template to help make this menu and it is only fair I give him credit!




Additial info:some people might call this skidding but it not reason bc Malachi makes the template to help others make menus so I am literally doing what he made it for! 




Contact Me Here!
Name:I like to stay anonymous but u can call me dead!
discord:dead_user_xoxo
Email:dead_user_xoxo@yahoo.com
